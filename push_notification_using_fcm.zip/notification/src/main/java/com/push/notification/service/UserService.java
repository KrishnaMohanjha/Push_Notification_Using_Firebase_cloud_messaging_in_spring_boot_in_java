package com.push.notification.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import com.push.notification.entity.User;

@Service
public class UserService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserService.class);

    public String sendNotification(User user) {
        String response = null;

        Notification notification = Notification.builder()
                .setTitle(user.getTitle())
                .setBody(user.getMessage())
                .build();
        
        Message message = Message.builder()
                .setToken(user.getToken())
                .setNotification(notification)
                .build();

        try {
            response = FirebaseMessaging.getInstance().send(message);
            LOGGER.info("Notification sent successfully. Response: " + response);
        } catch (FirebaseMessagingException e) {
            LOGGER.error("Failed to send notification. Error: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            LOGGER.error("An unexpected error occurred while sending notification", e);
            e.printStackTrace();
        }

        return response;
    }
}
